package airlineSystem;

public class About {
	public void gaurav1() {		
		System.out.println(" Airline reservation system is web-based system that helps in consolidating flight data\n - flight schedules, seat availability, flight fares and reservations from all airlines\n with the help of global distribution systems and provides  real-time inventory and rates \nfor customers and travel agents to book flight tickets online. " );
		System.out.println(" About our project\n We have made Airline Reservation system as our project for ST 2021 \n "
				+ "• The “Airline Reservation System” project is an attempt to stimulate the basic concepts of the reservation systems we see in our daily lives.\r\n"
				+ "• This system will enable the user or the customer to access the services for reservation in an airline.\r\n"
				+ "• This system will enable the user to book the flight between the states the want to travel i.e., Departure city and Arrival city.\r\n"
				+ "• The system will display all the flight details such as flight number, name, price, timings and flight duration.\n\n\n");
		}
}
