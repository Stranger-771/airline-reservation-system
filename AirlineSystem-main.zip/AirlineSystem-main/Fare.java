package airlineSystem;

public class Fare {

	public void gaurav() {
		System.out.println("Flights available on Delhi to Mumbai route And their Fare is  :-" );
		System.out.println("Flight Name\t Economy Fare \t\tBussiness Fare");
		System.out.println("DM48\t\t2000\t\t\t2500 \nDM24\t\t1800\t\t\t2300 \nDM36\t\t2200\t\t\t2700\n  ");
		
		System.out.println("Flights available on Delhi to Lucknow route And their Fare is  :-" );
		System.out.println("Flight Name\t Economy Fare \t\tBussiness Fare");
		System.out.println("DL81\t\t3300\t\t\t3500 \nDL96\t\t2950\t\t\t3400 \nDL77\t\t3250\t\t\t3400 \n  ");
		
		System.out.println("Flights available on Lucknow to Mumbai route And their Fare is  :-" );
		System.out.println("Flight Name\t Economy Fare \t\tBussiness Fare");
		System.out.println("LM80\t\t2650\t\t\t2900 \nLM76\t\t2400\t\t\t2700 \nLM98\t\t3200\t\t\t3500\n  ");
		
		System.out.println("Flights available on Lucknow to Delhi route And their Fare is  :-" );
		System.out.println("Flight Name\t Economy Fare \t\tBussiness Fare");
		System.out.println("LD75\t\t2300\t\t\t2500 \nLD69\t\t2000\t\t\t2900 \nLD33\t\t2700\t\t\t3000 \n  ");
		
		System.out.println("Flights available on  Mumbai to Delhi route And their Fare is  :-" );
		System.out.println("Flight Name\t Economy Fare \t\tBussiness Fare");
		System.out.println("MD76\t\t2000\t\t\t2700 \nMD98\t\t2800\t\t\t2500 \nMD15\t\t3250\t\t\t3750 \n ");
		
		System.out.println("Flights available on  Mumbai to Lucknow route And their Fare is  :-" );
		System.out.println("Flight Name\t Economy Fare \t\tBussiness Fare");
		System.out.println("ML98\t\t2200\t\t\t2500 \nML62\t\t1850\t\t\t2500 \nML16\t\t1900\t\t\t2500  \n\n\n");

	}

}
